﻿using System;

namespace TextAdventure
{
    public class Enemy
    {
        /*
         * Set EnemyBase as an abstract class...
         * Include abstract methods such as attack, guard, dodge, run....
         * Use interfaces for multiple enemy types....
        */
        abstract class EnemyBase
        {
            private string enemyName = "enemy";
            private string enemyClass = "class";
            private string enemyRank = "rank";
            private int hp = 0;
            private int attackStat = 0;
            private int defenceStat = 0;
            

            private EnemyBase(string name, string type, string rank, int health, int attack, int defence)
            {
                enemyName = name;
                enemyClass = type;
                enemyRank = rank;
                hp = health;
                attackStat = attack;
                defenceStat = defence;
                
            }
        
            /*
             * Setting mutators and accesssors
            */

            public int EnemyHealth
            {
                get { return hp;}
                set { hp = value; }
            }
            public int EnemyAttackPower
            {

            }

            public abstract void Attack();
            public abstract void Guard();
            //public abstract void Dodge(); Might consider placing this with specific enemy types.
            public abstract void Run();
        }

    }
}
