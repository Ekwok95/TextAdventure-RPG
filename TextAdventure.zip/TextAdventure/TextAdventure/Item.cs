﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure
{
    public class Item
    {
        //private string name;

        /*public string Item
        {
            get { return Item; }
            set { Item = ""; }
        }*/

        public Item(string itemName)
        {
            //name = itemName;
        }

        /*
        public override string ToString()
        {
            return name;
        }
        */
    }
}
