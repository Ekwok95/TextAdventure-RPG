﻿using System;
using System.IO;
using System.Threading;
using Microsoft.VisualBasic.FileIO;

//Created by Bryan Kwok Zhe Jian on 1/3/2017.

/* Timestamp and completed features.
 * 1/3/2017- Created base command system, player class and basic functions and actions.
 * 2/3/2017- Added commands, toString for objects, file I/O systems and help menu.
 * 3/3/2017- 
*/

/*
 * All action steps will involve creating commands for each action. Make commands no more than 20 characters unless this length is too short.
 *
 * * To do:
 * - Player save file and list- Done; Included a main menu.
 * - Enemy class- Can possibly split between evil NPCs and wild monsters....
 * - Enemy types- Normal enemies first. Add in bosses and boss room scenarios later....
 * - Set player stats also....
 * - Combat actions
 * - Level and experience system- Set enemies to be within suitable level range (not too high or low unless player stumbles into a high level area)
 *      - NO LEVEL CAP :D
 * - Create character classes (No magic characters. Physical weapons only. Can add enchant feature for weapons to reduce player disadvantage)
 *      - Have classes share SOME abilities, not all.
 *      - Create all abilities in advance.
 *      - Use binary tree to allow skill/advanced class tiers
 * - Armor and weapon types (Tiers and linked lists)- Set weapon stats to have a reasonable range(So that weapons don't become OP or UP).
 * - Weapon combos and abilities
 * - Death system
 * - Timed combat (If I can pull it off...)- Can adjust for other options
 * - Item Lists/Items- Gradually add to base list as game is being developed.
 * - Inventory- Create inventory with item details/stats. Also add inventory functions (Sorting functions, discard, etc..)
 * - NPCs- Friendly NPCs only. Enemies are already a class of their own.
 *      - Can add personalities to NPCs when game is complete (or more like adjusted properly).
 *      - Add conversation feature.
 * - Day and Night system- Set normal actions to take up approx normal time. Combat actions will take up a bit more time. 
 * Time will come in the form of turns/minutes in assumption of real life time....
 * - Status Effects (Maybe)
 * - Damage types (Maybe)
 * - Hunting system (Could allow linked lists also)- Hunting level in honour of Slayer skill on RS. :P
 * - Non-combat skills and actions
 * - Currency system (When most functions are in)
 * - Companions- If there is a need for additional support.
 * - Mounts (Not necessary but nice addition)
 * - Daily Challenges
 * - Dungeons
 * - Maps and location details
 * - Quests (Would love to have randomly generated quests; bounty hunting or otherwise) :D
 *      - Add level description to quests
 *      - Quest lines with linked lists/some other data structure.
 *      - Set quest ID for easy reference
 * - Difficulty Levels :P (Will consider it. No promises though.)
 * - Boss mechanics 0_0
 * - Playtime- Use Stopwatch class methods and Stopwatch.Elapsed method then write this timestamp to file.
 *      - Retrive timestamp and add onto new elapsed time.
 * - Achievements
*/

namespace TextAdventure
{
    public class Player
    {
        private string name;
        //public string characterClass;

        public Player(string nm)
        {
            name = nm;
        }

        public override string ToString()
        {
            return name;
        }

    }

    public class Test
    {
        private class Commands
        {
            private string command;
            private int commandNumber;

            public Commands(string name, int number)
            {
                command = name;
                commandNumber = number;
            }

            public override string ToString()
            {
                return "[" + commandNumber + "]---   " + command;
            }
        }

        private const int NUMBER_OF_COMMANDS = 4;

        public static void runGame(string[] character)
        {
            string intention, direction = "", temp = "", name = "";
            int steps = 0;
            bool justLoggedIn = true;

            ClearLine();
            Console.WriteLine("Enter name pls");
            name = Console.ReadLine();
            Player player = new Player(name);

            ClearLine();
            //Change code for object creation.... 
            //Current code is placeholder....
            if (player == null)
            {
                Console.WriteLine("Welcome to TextAdventure!!");
                Console.WriteLine("Please enter a name");
                string user = Console.ReadLine();
                Player player1 = new Player(user);
            }

            Actions setOfActions = new Actions();

            //Place all movement, combat and misc actions into actions class....
            //Make individual action types/classes and then combine into final Action class....
            
            if (justLoggedIn == true)
            {
                Console.WriteLine("Welcome back {0}.", player);  
                justLoggedIn = false;
            }

            do
            {
                //Check for user in file.

                /* if(Player == null)
                 {
                    Console.WriteLine("Welcome to ...");
                    Console.WriteLine("Please enter a name");
                    string user = Console.ReadLine();
                    Player player1 = new Player(user);
                 }
                 */
                intention = AskPlayer(0);

                /*if(Console.ReadKey(true).Key == ConsoleKey.Escape)
                {
                    Debug.WriteLine("Escape Key was pressed.");
                }*/

                //Search semaphores and mutex processes online

                ClearLine();

                if (intention.Equals("help"))
                {
                    ShowCommands();
                }

                if (intention.Equals("lookaround"))
                {
                    //Set random number depending on area and situation

                    //After further development, change this line to include multiple situations of similar scenarios.
                    Console.WriteLine("You look around and spot {0}.");
                }
                //Consider making sight/perception class....

                //Combat actions....

                //

                if (intention.Equals("walk"))
                {
                    temp = AskPlayer(1);
                    steps = Int32.Parse(temp);
                    Console.WriteLine("Which direction would you like to walk towards?");
                    direction = Console.ReadLine();
                    setOfActions.Walk(steps, direction);
                }

                if (intention.Equals("run"))
                {
                    temp = AskPlayer(1);
                    steps = Int32.Parse(temp);
                    Console.WriteLine("Which direction would you like to run towards?");
                    direction = Console.ReadLine();
                    setOfActions.Walk(steps * 2, direction);
                    //Consider making movement class...
                }

                /*
                else if (intention.Equals("quit"))
                {
                    Console.WriteLine("Do you really want to quit?");
                    string finalDecision = Console.ReadLine();
                    bool decision = End(finalDecision);
                    if (decision)
                    {
                        Thread.Sleep(3000);
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Command invalid. Please try again.");
                    Console.WriteLine("If you need help, type in 'help' in the next line.");
                }
                ClearLine();
                */

            } while (true);
        }

        /*private static void GameStart()
        {
            
        }*/

        public static void ClearLine()
        {
            Console.WriteLine("");
        }

        private static string AskPlayer(int decision)
        {
            string action = "";
            string response = "";
            string actions = "";

            if (decision == 0)
            {
                Console.WriteLine("Please perform an action.");
                ClearLine();
                action = Console.ReadLine();
                response = action;
            }
            else if (decision == 1)
            {
                Console.WriteLine("How many actions would you like to perform?");
                ClearLine();
                actions = Console.ReadLine();
                response = actions;
            }

            return response;
        }

        private static void ShowCommands()
        {
            string commandFile = "commands.txt";

            string[] commands = ReadLines(commandFile);
                
            Commands[] listOfCommands = new Commands[NUMBER_OF_COMMANDS];
            for(int i = 0; i < NUMBER_OF_COMMANDS; i++)
            {
                int number = i;
                listOfCommands[i] = new Commands(commands[i], number);
            }

            Console.WriteLine("In order to perform an action, you must type in a command.");
            Console.WriteLine("The available actions are as follows: ");

            for (int i=0;i<NUMBER_OF_COMMANDS;i++)
            {
                Console.WriteLine("{0}", listOfCommands[i]);
            }

            Console.WriteLine("Make sure to type commands all in lowercase with no spaces.");
            //Console.ReadKey();
        }

        public static string[] ReadLines(string filename)
        {
            string tempLine = "";
            int numberOfLines = 0;
            string[] lines, outputLines = null;

            StreamReader srread = new StreamReader(filename);
            try
            {
                tempLine = srread.ReadLine();
                Int32.TryParse(tempLine, out numberOfLines);
                lines = new string[numberOfLines];

                for(int i=0;i<numberOfLines;i++)
                {
                    lines[i] = srread.ReadLine();
                }

                outputLines = lines;
                
            }
            catch (FileNotFoundException FileNotFoundException)
            {
                Console.WriteLine("This file could not be read");
                Console.WriteLine(FileNotFoundException.Message);
            }
            catch(NullReferenceException NullException)
            {
                Console.WriteLine("There is nothing in this variable");
                Console.WriteLine(NullException.Message);
            }
            finally
            {
                if(srread != null)
                {
                    srread.Close();
                }
            }
            return outputLines;
        }

        public static void CreateNewFile(string filename)
        {
            ClearLine();
           
            if (!FileSystem.FileExists(filename))
            {
                StreamWriter writer = File.AppendText(filename);
                try
                {
                    if (FileSystem.FileExists(filename))
                    {
                        Console.WriteLine("A new save file has been created.");
                        ClearLine();
                    }
                    //Probably redundant and can swap for using block instead of try-finally...
                    else if (!FileSystem.FileExists(filename))
                    {
                        throw new FileNotFoundException("There was an error in creating a new save file.");
                    }
                }
                finally
                {
                    if (writer != null)
                    {
                        writer.Close();
                    }
                }
            }
            else
            {
                Console.WriteLine("A save file already exists. It would be pointless to create one.");
                ClearLine();
            }

            //Thread.Sleep(5000);
        }

        //Consider getting userDetails from Player object/class...
        //Consider maintaining save file data in an object...
        public static void WriteToSaveFile(string[] userDetails, int numberOfFields, string filename)
        { 
            if (!FileSystem.FileExists(filename))
            {
                using (StreamWriter srread = new StreamWriter(filename))
                {
                    numberOfFields.ToString();
                    srread.WriteLine(numberOfFields);

                    for(int i = 0; i < numberOfFields; i++)
                    {
                        srread.WriteLine(userDetails[i]);
                    }
                    Console.WriteLine("Character data saved.");
                }
            }
            else
            {
                throw new FileNotFoundException("File does not exist. Please make a new save file.");
            }

            Thread.Sleep(5000);
        }

        /*
         * Functions within this comment block has been tested and works.

        private static void testWriteToFile()
        {
            string[] playerdetails = { "Ekwok" };
            int fields = 1;
            string file = "savedata.txt";

            WriteToSaveFile(playerdetails, fields, file);
        }
        
        */
    }  
}
